import java.util.Random;
import java.util.Scanner;

public class BigMonster extends Monster {
    BigMonster(int sizeBoard) {
        super(sizeBoard);
        setImage("\uD83D\uDC79");
    }

    @Override
    public String getImage() {
        return "\uD83D\uDC79";
    }

    @Override
    public int taskMonster(int pl, int dif) {
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        if (pl > 0) {
            long a = random.nextLong((long) Math.pow(100, dif));
            long b = random.nextLong((long) Math.pow(100, dif));
            long c = random.nextLong((long) Math.pow(100, dif));
            long trueAnswer = a + b - c;
            System.out.println("Реши пример: " + a + " + " + b + " - " + c + " = ?");
            long ans = scanner.nextLong();
            if (trueAnswer == ans) {
                System.out.println("Верно! Ты победил монстра");
                pl++;
            } else {
                System.out.println("Ты проиграл эту битву!");
                pl--;
            }
        }
        if (pl == 0) {
            long a = random.nextLong((long) Math.pow(100, dif));
            long b = random.nextLong((long) Math.pow(100, dif));
            long trueAnswer = a + b;
            System.out.println("Реши пример: " + a + " + " + b + " = ?");
            long ans = scanner.nextInt();
            if (trueAnswer == ans) {
                System.out.println("Верно! Ты победил монстра");
                pl++;
            } else {
                System.out.println("Ты проиграл эту битву!");
                pl--;
            }
        }
        return pl;
    }
}
