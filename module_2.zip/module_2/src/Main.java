import java.util.Random;
import java.util.Scanner;
public class Main {
    void main() {
        int step = 0;
        int sizeBoard = 5;
        String castle = "\uD83C\uDFF0";
        String block = " | ";
        String wall = " + —— + —— + —— + —— + —— + ";
        Random random = new Random();
        int castleX = 1 + random.nextInt(sizeBoard);
        int castleY = 1;
        String[][] board = new String[sizeBoard][sizeBoard];
        for (int y = 1; y <= sizeBoard; y++) {
            for (int x = 1; x <= sizeBoard; x++) {
                board[y - 1][x - 1] = "  ";
            }
        }
        int countMonster = sizeBoard * sizeBoard - sizeBoard - 1;
        Monster[] monsters = new Monster[countMonster];
        int count = 0;
        while (count < countMonster) {
            Monster monster;
            if (random.nextBoolean()) {
                monster = new Monster(sizeBoard);
            } else {
                monster = new BigMonster(sizeBoard);
            }
            int row = monster.getX() - 1;
            int column = monster.getY() - 1;
            if (board[row][column].equals("  ")) {
                board[row][column] = monster.getImage();
                monsters[count] = monster;
                count++;
            }
        }
        Person person = new Person(sizeBoard);
        Merchant merchant = new Merchant(sizeBoard);
        System.out.println("Привет! Ты готов начать играть в игру? (Напиши: ДА или НЕТ)");
        Scanner scanner = new Scanner(System.in);
        String answer = scanner.nextLine();
        switch (answer) {
            case "ДА":
                System.out.println("Выбери сложность (от 1 до 5).");
                int difficulty = scanner.nextInt();
                if (difficulty > 5 || difficulty < 1) {
                    System.out.println("Всё понятно... Считать до пяти мы не умеем...");
                } else {
                    System.out.println("Вы выбрали сложность: " + difficulty);
                    while ((person.getLive() > 0) && !(castleX == person.getX() && castleY == person.getY())) {
                        board[merchant.getY() - 1][merchant.getX() - 1] = merchant.getImage();
                        board[person.getY() - 1][person.getX() - 1] = person.getImage();
                        board[castleY - 1][castleX - 1] = castle;
                        for (String[] row : board) {
                            System.out.println(wall);
                            for (String cell : row) {
                                System.out.print(block);
                                System.out.print(cell);
                            }
                            System.out.println(block);
                        }
                        System.out.println(wall);
                        System.out.println("Жизней: " + person.getLive());
                        System.out.println("Введите куда будет ходить персонаж (ход возможен только по вертикали и горизонтали на одну клетку)");
                        System.out.println("Координаты персонажа - (x: " + person.getX() + ", y: " + person.getY() + ")");
                        int x = scanner.nextInt();
                        int y = scanner.nextInt();
                        if(person.isMoveCorrect(x, y)) {
                            board[person.getY() - 1][person.getX() - 1] = "  ";
                            person.move(x, y);
                            step++;
                            if (board[y - 1][x - 1].equals("  ")) {
                                System.out.println("Ход корректен.");
                            } else if (board[y - 1][x - 1].equals("\uD83E\uDDDF") || board[y - 1][x - 1].equals("\uD83D\uDC79")) {
                                for (Monster monster: monsters) {
                                    if (monster.conflictPerson(x, y)) {
                                        person.setLive(monster.taskMonster(person.getLive(), difficulty));
                                    }
                                }
                            } else {
                                person.setLive(person.getLive() + 1);
                                merchant.setX(castleX);
                                merchant.setY(castleY);
                            }
                        }
                    }
                    if (person.getLive() <= 0) {
                        System.out.println("Поздравляю! Вы проиграли! Если Вы этому не рады, сыграйте ещё раз.");
                    } else {
                        System.out.println("Ладно, так уж и быть, Вы победили. Если Вы рады, сыграйте ещё раз!");
                    }
                }
                break;
            case "НЕТ":
                System.out.println("Я обиделся.");
                break;
            default:
                System.out.println("Ну не умеешь ты нормально на вопрос отвечать!!! Можно вообще корректно данные вводить?");
                break;
        }
    }
}