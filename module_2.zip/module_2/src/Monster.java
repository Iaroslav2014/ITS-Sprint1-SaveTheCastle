import java.util.Random;
import java.util.Scanner;

public class Monster {
    private String image = "\uD83E\uDDDF";
    private int x, y;

    Monster(int sizeBoard) {
        Random random = new Random();
        x = 1 + random.nextInt(sizeBoard);
        y = 1 + random.nextInt(sizeBoard);
    }

    public boolean conflictPerson(int personX, int personY) {
        return personX == x && personY == y;
    }

    public String getName() {
        return "m";
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getImage() {
        return image;
    }

    public int taskBigMonster(int pl, int dif) {
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        if (pl > 0) {
            long a = random.nextLong((long) Math.pow(100, dif));
            long b = random.nextLong((long) Math.pow(100, dif));
            long c = random.nextLong((long) Math.pow(100, dif));
            long trueAnswer = a + b - c;
            System.out.println("Реши пример: " + a + " + " + b + " - " + c + " = ?");
            long ans = scanner.nextLong();
            if (trueAnswer == ans) {
                System.out.println("Верно! Ты победил монстра");
                pl++;
            } else {
                System.out.println("Ты проиграл эту битву!");
                pl--;
            }
        }
        if (pl == 0) {
            long a = random.nextLong((long) Math.pow(100, dif));
            long b = random.nextLong((long) Math.pow(100, dif));
            long trueAnswer = a + b;
            System.out.println("Реши пример: " + a + " + " + b + " = ?");
            long ans = scanner.nextInt();
            if (trueAnswer == ans) {
                System.out.println("Верно! Ты победил монстра");
                pl++;
            } else {
                System.out.println("Ты проиграл эту битву!");
                pl--;
            }
        }
        return pl;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int taskMonster(int pl, int dif) {
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        if (pl > 0) {
            long a = random.nextLong((long) Math.pow(10, dif));
            long b = random.nextLong((long) Math.pow(10, dif));
            long trueAnswer = a + b;
            System.out.println("Реши пример: " + a + " + " + b + " = ?");
            long ans = scanner.nextLong();
            if (trueAnswer == ans) {
                System.out.println("Верно! Ты победил монстра");
                pl++;
            } else {
                System.out.println("Ты проиграл эту битву!");
                pl--;
            }
        }
        if (pl == 0) {
            long a = random.nextLong((long) Math.pow(10, dif));
            long b = random.nextLong((long) Math.pow(10, dif));
            long trueAnswer = a + b;
            System.out.println("Реши пример: " + a + " + " + b + " = ?");
            long ans = scanner.nextInt();
            if (trueAnswer == ans) {
                System.out.println("Верно! Ты победил монстра");
                pl++;
            } else {
                System.out.println("Ты проиграл эту битву!");
                pl--;
            }
        }
        return pl;
    }
}
