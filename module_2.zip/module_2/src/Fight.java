import java.util.Random;
import java.util.Scanner;

public class Fight {
    void main() {
        int hph = 100;
        int hpd = 150;
        int countz = 3;
        int steps = 0;
        int dri = 1;
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Удар мечом\n2. Сокрушительный удар\n3. Зелье");
            int ans = scanner.nextInt();
            if (ans == 1) {
                hpd -= (random.nextInt(10) + 11);
                System.out.println(hpd);
            } else if (ans == 2) {
                if (random.nextInt(2) == 1) {
                    hpd -= 35;
                    System.out.println(hpd);
                }
            } else {
                if (countz > 0) {
                    hph += 30;
                    if (hph > 100) {
                        hph = 100;
                    }
                    countz--;
                    System.out.println(hph);
                } else {
                    System.out.println("Зелья кончились, время потрачено.");
                }
            }
            steps++;
            if (hpd <= 0) {
                System.out.println("Игрок");
                System.out.println(steps);
                break;
            }
            System.out.println("---");
            if (dri != 3) {
                dri++;
                hph -= (random.nextInt(8) + 8);
                System.out.println(hph);
            } else {
                dri = 1;
                hph -= 25;
                System.out.println(hph);
            }
            if (hph <= 0) {
                System.out.println("Дракон");
                System.out.println(steps);
                break;
            }
        }
    }
}
